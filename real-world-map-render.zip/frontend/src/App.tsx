import { useEffect, useRef, useState } from "react";
import maplibregl, { Map, Marker } from "maplibre-gl";

type Place = {
  id: string; name: string; type: string; icon: string; color: string;
  description: string; note: string; imageUrl?: string | null;
  latitude: number; longitude: number; favorite: boolean;
};

const API = "/api";
const mapKey = import.meta.env.VITE_MAPTILER_API_KEY || "";

function styleUrl() {
  if (mapKey) return `https://api.maptiler.com/maps/streets-v2/style.json?key=${mapKey}`;
  return "https://demotiles.maplibre.org/style.json";
}

const empty = { name:"Địa điểm mới", type:"other", icon:"📍", color:"#2563eb", description:"", note:"", latitude:10.4114, longitude:107.1362, favorite:false };

export default function App() {
  const mapEl = useRef<HTMLDivElement>(null);
  const mapRef = useRef<Map | null>(null);
  const markers = useRef<Record<string, Marker>>({});
  const [places, setPlaces] = useState<Place[]>([]);
  const [selected, setSelected] = useState<Place | null>(null);
  const [form, setForm] = useState<any>(empty);
  const [adding, setAdding] = useState(false);
  const [vipOpen, setVipOpen] = useState(false);
  const [vipCode, setVipCode] = useState("");
  const [vip, setVip] = useState(false);
  const [search, setSearch] = useState("");
  const [mode, setMode] = useState<"2D"|"3D">("3D");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!mapEl.current) return;
    const map = new maplibregl.Map({
      container: mapEl.current,
      style: styleUrl(),
      center: [107.1362, 10.4114],
      zoom: 3,
      pitch: 45,
      attributionControl: true
    });
    map.addControl(new maplibregl.NavigationControl(), "bottom-right");
    map.on("load", () => setLoading(false));
    map.on("click", (e) => {
      if (!adding) return;
      setForm({ ...empty, latitude: e.lngLat.lat, longitude: e.lngLat.lng });
      setSelected(null);
    });
    mapRef.current = map;
    return () => map.remove();
  }, [adding]);

  useEffect(() => {
    fetch(`${API}/places`).then(r => r.json()).then(setPlaces)
      .catch(() => setError("Không tải được dữ liệu địa điểm."))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (!mapRef.current) return;
    Object.values(markers.current).forEach(m => m.remove());
    markers.current = {};
    places.forEach(p => {
      const el = document.createElement("button");
      el.className = "marker";
      el.style.background = p.color;
      el.textContent = p.icon;
      el.title = p.name;
      el.onclick = (ev) => { ev.stopPropagation(); setSelected(p); setForm(p); mapRef.current?.flyTo({center:[p.longitude,p.latitude], zoom:15}); };
      markers.current[p.id] = new maplibregl.Marker({element:el}).setLngLat([p.longitude,p.latitude]).addTo(mapRef.current!);
    });
  }, [places]);

  async function save() {
    setError("");
    const editing = Boolean(form.id);
    const res = await fetch(editing ? `${API}/places/${form.id}` : `${API}/places`, {
      method: editing ? "PATCH" : "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify(form)
    });
    if (!res.ok) { setError("Không thể lưu địa điểm."); return; }
    const saved = await res.json();
    setPlaces(old => editing ? old.map(p => p.id === saved.id ? saved : p) : [saved, ...old]);
    setSelected(saved); setAdding(false);
  }

  async function remove() {
    if (!form.id) return;
    const res = await fetch(`${API}/places/${form.id}`, {method:"DELETE"});
    if (!res.ok) { setError("Không thể xóa địa điểm."); return; }
    setPlaces(old => old.filter(p => p.id !== form.id));
    setSelected(null);
  }

  async function verifyVip() {
    const res = await fetch(`${API}/vip/verify`, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({code:vipCode})});
    const data = await res.json();
    setVip(Boolean(data.valid));
    if (!data.valid) setError("Mã VIP không hợp lệ.");
    else { setVipOpen(false); setError(""); }
  }

  function findPlace() {
    const q = search.trim().toLowerCase();
    const p = places.find(x => x.name.toLowerCase().includes(q));
    if (p) { mapRef.current?.flyTo({center:[p.longitude,p.latitude],zoom:15}); setSelected(p); setForm(p); return; }
    setError("Chưa tìm thấy địa điểm tùy chỉnh. Với tìm kiếm toàn cầu, hãy cấu hình geocoder/provider được cấp phép.");
  }

  return <div className="app">
    <div ref={mapEl} className="map" />
    <header className="topbar">
      <div className="brand">🌍 <b>REAL WORLD MAP</b><span>3D</span></div>
      <div className="search"><input value={search} onChange={e=>setSearch(e.target.value)} onKeyDown={e=>e.key==="Enter"&&findPlace()} placeholder="Tìm địa điểm..." /><button onClick={findPlace}>🔍</button></div>
    </header>

    <aside className="panel left">
      <button className="primary" onClick={()=>{setAdding(true);setForm(empty)}}>＋ Thêm địa điểm</button>
      <button onClick={()=>setAdding(v=>!v)}>📍 {adding?"Đang chọn vị trí...":"Chọn trên bản đồ"}</button>
      <button onClick={()=>setMode(mode==="3D"?"2D":"3D")}>🧭 {mode}</button>
      <button onClick={()=>mapRef.current?.flyTo({center:[0,20],zoom:1.5})}>🌐 Toàn thế giới</button>
      <button onClick={()=>setVipOpen(true)}>👑 VIP</button>
      {vip && <div className="vipBadge">VIP đã mở</div>}
    </aside>

    <aside className="panel right">
      <h3>📌 Địa điểm</h3>
      <div className="placeList">
        {places.map(p=><button key={p.id} className="placeRow" onClick={()=>{setSelected(p);setForm(p);mapRef.current?.flyTo({center:[p.longitude,p.latitude],zoom:15})}}><span>{p.icon}</span><span>{p.name}</span>{p.favorite&&<span>⭐</span>}</button>)}
        {!places.length && <div className="muted">Chưa có địa điểm nào.</div>}
      </div>
    </aside>

    {selected && <div className="editor">
      <div className="editorHead"><b>Chỉnh sửa địa điểm</b><button onClick={()=>setSelected(null)}>✕</button></div>
      <label>Tên<input value={form.name||""} onChange={e=>setForm({...form,name:e.target.value})}/></label>
      <label>Loại<input value={form.type||""} onChange={e=>setForm({...form,type:e.target.value})}/></label>
      <div className="two"><label>Icon<input value={form.icon||"📍"} onChange={e=>setForm({...form,icon:e.target.value})}/></label><label>Màu<input type="color" value={form.color||"#2563eb"} onChange={e=>setForm({...form,color:e.target.value})}/></label></div>
      <label>Mô tả<textarea value={form.description||""} onChange={e=>setForm({...form,description:e.target.value})}/></label>
      <label>Ghi chú<textarea value={form.note||""} onChange={e=>setForm({...form,note:e.target.value})}/></label>
      <label className="check"><input type="checkbox" checked={Boolean(form.favorite)} onChange={e=>setForm({...form,favorite:e.target.checked})}/> ⭐ Yêu thích</label>
      <div className="actions"><button className="primary" onClick={save}>💾 Lưu</button>{form.id&&<button className="danger" onClick={remove}>🗑 Xóa</button>}</div>
    </div>}

    {adding && !selected && <div className="hint">Chạm vào bản đồ để đặt địa điểm mới.</div>}
    {vipOpen && <div className="modal"><div className="dialog"><h2>👑 VIP</h2><p>Nhập mã VIP để kiểm tra ở máy chủ.</p><input value={vipCode} onChange={e=>setVipCode(e.target.value)} placeholder="Nhập mã VIP"/><div className="actions"><button onClick={()=>setVipOpen(false)}>Hủy</button><button className="primary" onClick={verifyVip}>Xác nhận</button></div></div></div>}
    {error && <div className="toast">⚠️ {error}<button onClick={()=>setError("")}>✕</button></div>}
    {loading && <div className="loading">Đang tải bản đồ…</div>}
  </div>;
}